$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root   = Split-Path -Parent $MyInvocation.MyCommand.Path
$pack   = Join-Path $root 'musik-pack'
$sndDir = Join-Path $pack 'assets\musik\sounds'
$utf8   = New-Object System.Text.UTF8Encoding $false

function Get-OggSeconds($path) {
    $b = [System.IO.File]::ReadAllBytes($path)
    $rate = 0
    $max = [Math]::Min($b.Length - 20, 400)
    for ($i = 0; $i -lt $max; $i++) {
        if ($b[$i] -eq 1 -and $b[$i+1] -eq 0x76 -and $b[$i+2] -eq 0x6F -and $b[$i+3] -eq 0x72 -and $b[$i+4] -eq 0x62 -and $b[$i+5] -eq 0x69 -and $b[$i+6] -eq 0x73) {
            $rate = [BitConverter]::ToUInt32($b, $i + 12); break
        }
    }
    $last = -1
    for ($i = $b.Length - 14; $i -ge 0; $i--) {
        if ($b[$i] -eq 0x4F -and $b[$i+1] -eq 0x67 -and $b[$i+2] -eq 0x67 -and $b[$i+3] -eq 0x53) { $last = $i; break }
    }
    if ($rate -eq 0 -or $last -lt 0) { return 0 }
    $gran = [BitConverter]::ToInt64($b, $last + 6)
    return [int][Math]::Ceiling($gran / $rate)
}

$oggs = @(Get-ChildItem $sndDir -Filter *.ogg | Sort-Object Name)
if ($oggs.Count -eq 0) {
    Write-Host "FEHLER: Keine .ogg-Datei in $sndDir gefunden." -ForegroundColor Red
    exit 1
}
foreach ($f in $oggs) {
    if ($f.BaseName -cnotmatch '^[a-z0-9_-]+$') {
        Write-Host "FEHLER: Ungueltiger Dateiname '$($f.Name)'. Erlaubt: nur kleine Buchstaben, Zahlen, _ und -" -ForegroundColor Red
        exit 1
    }
}

# sounds.json automatisch erzeugen
$entries = foreach ($f in $oggs) {
    '  "{0}": {{ "sounds": [ {{ "name": "musik:{0}", "stream": true }} ] }}' -f $f.BaseName
}
$json = "{`n" + ($entries -join ",`n") + "`n}`n"
[System.IO.File]::WriteAllText((Join-Path $pack 'assets\musik\sounds.json'), $json, $utf8)

# ZIP bauen (Schraegstriche im Pfad, wie Minecraft es braucht)
$zipPath = Join-Path $root 'musik-pack.zip'
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, 'Create')
try {
    Get-ChildItem $pack -Recurse -File | Where-Object { $_.Extension -ne '.txt' } | ForEach-Object {
        $name = $_.FullName.Substring($pack.Length + 1).Replace('\', '/')
        [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $name, [System.IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $zip.Dispose() }

$sha = (Get-FileHash $zipPath -Algorithm SHA1).Hash.ToLower()
[System.IO.File]::WriteAllText((Join-Path $root 'sha1.txt'), $sha, $utf8)

# Skript fuer die Dauerschleife aus der Vorlage erzeugen
$song  = $oggs[0].BaseName
$sek   = Get-OggSeconds $oggs[0].FullName
if ($sek -le 0) {
    Write-Host "WARNUNG: Laenge konnte nicht gelesen werden (nur Ogg-Vorbis wird von Minecraft unterstuetzt)." -ForegroundColor Yellow
    $sek = 180
}
$tpl = [System.IO.File]::ReadAllText((Join-Path $root 'BedwarsMusikLoop.vorlage'))
$tpl = $tpl.Replace('__SONG__', $song).Replace('__LAENGE__', [string]$sek)
[System.IO.File]::WriteAllText((Join-Path $root 'BedwarsMusikLoop.sk'), $tpl, $utf8)

Write-Host ""
Write-Host "FERTIG!" -ForegroundColor Green
Write-Host "  Song:        $song  ($sek Sekunden)"
Write-Host "  Resource Pack: musik-pack.zip"
Write-Host "  SHA1:        $sha  (steht auch in sha1.txt)"
Write-Host "  Skript:      BedwarsMusikLoop.sk -> in den Skript-Ordner des Servers legen"
if ($oggs.Count -gt 1) { Write-Host "  Hinweis: Mehrere Dateien im Pack, in Dauerschleife laeuft nur '$song'." -ForegroundColor Yellow }
